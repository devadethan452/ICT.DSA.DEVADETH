import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle

##load dataset
df = pd.read_excel("ProjectDataset.xlsx")


##split the data
x = df.drop(columns=['Diagnosis'])
y = df['Diagnosis']
x_train,x_test,y_train,y_test = train_test_split(x,y, random_state=42, test_size = 0.2)

##Train the model
model = RandomForestClassifier()
model.fit(x_train, y_train)

##Save model
pickle.dump(model, open('model.pkl', 'wb'))



