from flask import Flask,render_template,request
import pickle
import numpy as np

##load trained model
model =pickle.load(open('model.pkl','rb'))

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        BP = float(request.form['BP'])
        alcohol = 1 if request.form['alcohol'] == 'Yes' else 0
        smoking = 1 if request.form['smoking'] == 'Yes' else 0
        weight_changes = 1 if request.form['weight changes'] == 'Yes' else 0
        family_history = 1 if request.form['family history'] == 'Yes' else 0
        serum_creatinine = float(request.form['serum creatinine'])
        gfr = float(request.form['gfr'])
        bun = float(request.form['bun'])
        serum_calcium = float(request.form['serum calcium'])
        hematuria = 1 if request.form['hematuria'] == 'Yes' else 0
        oxalate_levels = float(request.form['oxalate levels'])
        urine_ph = float(request.form['urine ph'])
        water_intake = float(request.form['water intake'])

        stress_level = request.form['stress level']
        stl_dict = {'L':0 , 'M':1 , 'H':2}
        stress_level = stl_dict.get(stress_level, 2)

        physical_activity = request.form['physical activity']
        pa_dict = {'L':0 , 'M':1 , 'H':2}
        physical_activity = pa_dict.get(physical_activity, 2)

        ana = 1 if request.form['ana'] == 'Yes' else 0


        features = np.array([[BP,alcohol,smoking,weight_changes,family_history,serum_creatinine,gfr,bun,serum_calcium,hematuria,oxalate_levels,urine_ph,water_intake,stress_level,physical_activity,ana]])
        prediction = model.predict(features)
        result = "SORRY..YOU HAVE CHRONIC KIDNEY DISEASE. DON'T WORRY WE CAN CURE THIS" if prediction[0] == 1 else "CONGRATS..YOU DON'T HAVE CKD..KEEP YOUR HEALTH"
    except Exception as e:
        result = f"Error in prediction: {str(e)}"

    return render_template('result.html' , result=result)
if __name__ == '__main__':
    app.run(debug=True)
